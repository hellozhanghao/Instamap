Optimum Screen Size: 1680*1050

Authors: SUTD Team John Hall (Chiew Jun Hao, Nguyen Bao Ngan Sumi, Zhang Hao, Zhang Zhexian)